package com.example.minecraftaibuilder

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Minecraft AI Builder 0.1\nVersione di prova"
            textSize = 22f
            gravity = Gravity.CENTER
        }

        val info = TextView(this).apply {
            text = "Questa versione NON contiene ancora un'intelligenza artificiale.\n" +
                "Serve solo a verificare il collegamento con il servizio di accessibilità."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }

        val settingsButton = Button(this).apply {
            text = "Apri impostazioni di accessibilità"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val tapButton = Button(this).apply {
            text = "Esegui tocco di prova"
            setOnClickListener {
                val service = MinecraftAccessibilityService.instance
                if (service == null) {
                    Toast.makeText(this@MainActivity,
                        "Attiva prima Minecraft AI Builder nelle impostazioni di accessibilità.",
                        Toast.LENGTH_LONG).show()
                } else {
                    service.tapScreenCenter()
                    Toast.makeText(this@MainActivity, "Tocco di prova inviato.",
                        Toast.LENGTH_SHORT).show()
                }
            }
        }

        layout.addView(title)
        layout.addView(info)
        layout.addView(settingsButton)
        layout.addView(tapButton)
        setContentView(layout)
    }
}
